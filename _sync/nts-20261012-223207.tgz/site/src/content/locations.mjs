// Звёздная карта: где находится содержание. Координаты — в системе карты 1000×600 (HANDOFF → Карта).
// stages — этапы маршрута, на которых место становится актуальным (одна планета — несколько этапов = возвращение).
// Порядок массива = порядок маршрута (DOM-порядок кнопок и порядок Tab).
// spoiler: true — название раскрывает сюжет поздних квестов.
export const map = { width: 1000, height: 560, sun: [-420, 300], goldOrbit: 1420 };

export const locations = [
  { id: 'earth', name: 'Земля', orb: 'earth', x: 110, y: 330, stages: [1, 4, 8], wiki: 'Земля',
    lead: 'Начало пути: первые квесты, ресурсы для первых чертежей; позже — Цетус и Перья, а в поздней игре — пик Юван.',
    nodes: [
      { name: 'Цетус и Равнины Эйдолона', text: 'Острон, Перья (Онкко — первый модульный усилитель), заказы; ночью — охота на Эйдолонов.', stage: 3 },
      { name: 'Железная Цитадель', text: 'Палладино: закрытые моды разлома за Осколки Разлома (после «Цепей Харроу»).', stage: 3 },
      { name: 'Пик Юван', text: 'Колокола для The Icebind у ледяного столба; Мелика.', stage: 8, spoiler: true }
    ], resources: ['ferrite', 'rubedo', 'neurodes'] },
  { id: 'venus', access: [{ f: 'junction:earth-venus' }], name: 'Венера', orb: 'venus', x: 230, y: 230, stages: [1], wiki: 'Венера',
    lead: 'Fossa — бой с Шакалом, источник частей Рино. Фортуна и Долина Сфер — Объединение Солярис и Глас Солярис.',
    nodes: [
      { name: 'Fossa', text: 'Убийство Шакала: выпадают чертежи частей Рино.' },
      { name: 'Фортуна и Долина Сфер', text: 'Объединение Солярис (моды Связи, Китганы), Глас Солярис (усилители), ограбления Сферы Извлечения Прибыли с 5-го ранга.', stage: 2 }
    ], resources: ['polymer', 'alloy'] },
  { id: 'mercury', name: 'Меркурий', orb: 'mercury', x: 230, y: 420, stages: [1], wiki: 'Меркурий', size: 'sm',
    lead: 'Ранние миссии и Полимеры.', resources: ['polymer'] },
  { id: 'mars', access: [{ f: 'junction:earth-mars' }], name: 'Марс', orb: 'mars', x: 330, y: 330, stages: [2], wiki: 'Марс',
    lead: 'Начало середины карты: Вторсырьё, переходы к Церере и Деймосу.', resources: ['salvage'] },
  { id: 'phobos', name: 'Фобос', orb: 'mercury', x: 370, y: 440, stages: [2], wiki: 'Фобос', size: 'sm',
    lead: 'Пластиды на ранней карте.', resources: ['plastids'] },
  { id: 'deimos', access: [{ f: 'junction:earth-mars' }, { f: 'quest:heart-of-deimos', label: 'Для Некралиска и Камбионского Дрейфа — «Сердце Деймоса»' }], name: 'Деймос', orb: 'mars', x: 450, y: 200, stages: [2, 4, 5], wiki: 'Деймос',
    lead: '«Сердце Деймоса», Некралиск и Энтрати, хранилища Орокин; позже — сегмент Гельминта и некрамех.',
    nodes: [
      { name: 'Некралиск и Камбионский Дрейф', text: 'Энтрати (Сын — сегмент Гельминта и моды Связи), Некралоид (части некрамеха), заказы Матери, Изолированные хранилища.' },
      { name: 'Horend, Захват', text: 'Удобная миссия заброшенных кораблей для хранилищ Орокин (нужны ключи Дракона).' },
      { name: 'Armatus, Сбой', text: 'Источник частей Данте.' }
    ], resources: ['nano-spores', 'neurodes', 'mutagen'] },
  { id: 'ceres', name: 'Церера', orb: 'ceres', x: 480, y: 410, stages: [2], wiki: 'Церера',
    lead: 'Тёмные секторы Gabii и Seimeni для кредитов; Элементы Питания Орокин.',
    nodes: [{ name: 'Gabii, Seimeni', text: 'Тёмные секторы: короткие заходы ради кредитов; Gabii — Элементы Питания Орокин.' }],
    resources: ['orokin-cell', 'alloy'] },
  { id: 'jupiter', name: 'Юпитер', orb: 'jupiter', x: 570, y: 300, stages: [2], wiki: 'Юпитер',
    lead: 'Нейронные Датчики, Оксиум на Io, бой с Ропалолистом (Висп).',
    nodes: [
      { name: 'Io', text: 'Оксиумные дроны Корпуса — убивайте до самоуничтожения.' },
      { name: 'Ропалолист', text: 'Части Висп; доступ после «Химеры: Пролога».', stage: 3 }
    ], resources: ['neural-sensors', 'oxium', 'alloy', 'salvage'] },
  { id: 'europa', name: 'Европа', orb: 'europa', x: 600, y: 450, stages: [2], wiki: 'Европа', size: 'sm',
    lead: 'Часть основной карты; обязательные узлы нужны для Стального пути.' },
  { id: 'saturn', access: [{ f: 'junction:jupiter-saturn' }], name: 'Сатурн', orb: 'saturn', x: 620, y: 150, stages: [2], wiki: 'Сатурн',
    lead: 'Helene и Piscinas для ресурсов; переход на Уран открывает «Парадокс Дувири».',
    nodes: [{ name: 'Helene', text: 'Элементы Питания Орокин — совмещайте с синтезом и кредитами.' }, { name: 'Piscinas', text: 'Пластиды.' }],
    resources: ['orokin-cell', 'plastids', 'nano-spores'] },
  { id: 'uranus', access: [{ f: 'junction:saturn-uranus' }], name: 'Уран', orb: 'uranus', x: 710, y: 300, stages: [3], wiki: 'Уран',
    lead: 'Ophelia — Полимеры и редкий Теллуриум; отсюда дальше по сюжету.',
    nodes: [{ name: 'Ophelia', text: 'Удобна для долгого сбора Полимеров; подводные миссии дают Теллуриум.' }],
    resources: ['polymer', 'tellurium'] },
  { id: 'duviri', access: [{ f: 'quest:duviri' }], name: 'Дувири', orb: 'void', x: 770, y: 190, stages: [3, 6], wiki: 'Дувири', size: 'sm',
    lead: 'Цепь с чертежами варфреймов и Куллерво; позже — Стальная Цепь с адаптерами Инкарнон.',
    nodes: [{ name: 'Цепь и Стальная Цепь', text: 'Две награды недели на ступенях 5 и 10.' }, { name: 'Подземелье', text: 'Руническая Сущность.' }],
    resources: ['pathos-clamp', 'runic-essence'] },
  { id: 'neptune', access: [{ f: 'junction:uranus-neptune' }], name: 'Нептун', orb: 'neptune', x: 770, y: 420, stages: [3], wiki: 'Нептун',
    lead: 'Индекс — целевой источник кредитов; переход на Плутон.',
    nodes: [{ name: 'Индекс', text: 'Ставка кредитами; выбирайте ставку, потерю которой можете позволить.' }], resources: ['nano-spores'] },
  { id: 'pluto', access: [{ f: 'junction:neptune-pluto' }], name: 'Плутон', orb: 'pluto', x: 850, y: 300, stages: [3], wiki: 'Плутон',
    lead: 'Задача перехода Плутон → Эрида: «установить линзу Фокуса» открывает Арбитражи.' },
  { id: 'eris', name: 'Эрида', orb: 'pluto', x: 880, y: 440, stages: [3, 4], wiki: 'Эрида', size: 'sm',
    lead: 'Naeglar — тайники Диверсии Улья (60/60 Электро); Образец Мутагена.',
    nodes: [{ name: 'Naeglar, Диверсия Улья', text: 'Три тайника — нужная последняя таблица наград.' }], resources: ['nano-spores', 'mutagen'] },
  { id: 'sedna', name: 'Седна', orb: 'mars', x: 880, y: 170, stages: [3], wiki: 'Седна', size: 'sm',
    lead: 'Арена (в том числе Vodyanoi) — групповой фарм Эндо; Вторсырьё.', resources: ['salvage'] },
  { id: 'lua', access: [{ f: 'quest:second-dream' }], name: 'Луа', orb: 'mercury', x: 70, y: 220, stages: [3], wiki: 'Луа', size: 'sm',
    lead: 'Открывается после «Второго Сна». Apollo — Сбой для реликвий Акси.', resources: ['neurodes'] },
  { id: 'kuva', access: [{ f: 'quest:war-within' }], name: 'Крепость Кувы', orb: 'mars', x: 960, y: 290, stages: [3], wiki: 'Крепость_Кувы', size: 'sm',
    lead: 'После «Войны Внутри»: Шпионаж уровня 3 для модов 60/60 Холода и Огня, миссии Кувы.' },
  { id: 'void', name: 'Бездна', orb: 'void', x: 680, y: 520, stages: [3], wiki: 'Бездна', size: 'sm',
    lead: 'Hepit (реликвии Лит), Ukko (Мезо и Нео), Кристалл Аргона; Порабощённый Вор на высоких уровнях.',
    resources: ['argon'] },
  { id: 'proxima', access: [{ f: 'flag:railjack' }], name: 'Проксимы', orb: 'neptune', x: 975, y: 410, stages: [5, 7], wiki: 'Рэйлджек', size: 'sm',
    lead: 'Миссии Рейлджека; позже — Стальной Рейлджек и Созвездия.' },
  { id: 'zariman', access: [{ f: 'quest:zariman' }], name: 'Зариман', orb: 'void', x: 810, y: 520, stages: [6], wiki: 'Зариман', size: 'sm', spoiler: true,
    lead: 'Хризалит и Неукротимые (Кавальеро): Инкарнон-оружие, мистификаторы, Каскад Бездны.', resources: ['voidplume'] },
  { id: 'sanctum', access: [{ f: 'quest:whispers' }], name: 'Санктум Анатомика', orb: 'mars', x: 520, y: 60, stages: [6, 7, 8], wiki: 'Санктум_Анатомика', size: 'sm', spoiler: true,
    lead: 'Кавия (Птичка-3), Ячейки Нетры, Глубинная Архимедия.', resources: ['voca'] },
  { id: 'hollvania', access: [{ f: 'quest:hex' }], name: 'Хёльвания', orb: 'ceres', x: 960, y: 70, stages: [7, 8], wiki: 'Хёльвания', size: 'sm', spoiler: true,
    lead: 'Синдикат Гекс (Элеонора), Временная Архимедия (Кая), Техноцит Кода.' },
  { id: 'cathedrale', access: [{ f: 'quest:old-peace' }], name: 'La Cathédrale', orb: 'europa', x: 720, y: 40, stages: [7], wiki: 'La_Cathédrale', size: 'sm', spoiler: true,
    lead: 'Мари: артефакты Фокуса; через Тёмный Рефракторий — Спуск и Восстание Периты.' }
];

// Связи маршрута (не переходы игры!): этап, на котором связь входит в маршрут, и её роль.
// kind: main — основной путь, branch — дополнительная ветка, return — возвращение к уже открытой планете.
export const edges = [
  { from: 'earth', to: 'venus', stage: 1, kind: 'main' },
  { from: 'venus', to: 'mercury', stage: 1, kind: 'branch', bend: -0.25 },
  { from: 'earth', to: 'mars', stage: 2, kind: 'main', bend: -0.1 },
  { from: 'mars', to: 'phobos', stage: 2, kind: 'branch', bend: 0.2 },
  { from: 'mars', to: 'deimos', stage: 2, kind: 'main' },
  { from: 'mars', to: 'ceres', stage: 2, kind: 'main' },
  { from: 'ceres', to: 'jupiter', stage: 2, kind: 'main' },
  { from: 'jupiter', to: 'europa', stage: 2, kind: 'branch', bend: 0.15 },
  { from: 'jupiter', to: 'saturn', stage: 2, kind: 'main' },
  { from: 'saturn', to: 'uranus', stage: 3, kind: 'main' },
  { from: 'uranus', to: 'duviri', stage: 3, kind: 'branch', bend: -0.2 },
  { from: 'uranus', to: 'neptune', stage: 3, kind: 'main' },
  { from: 'neptune', to: 'pluto', stage: 3, kind: 'main' },
  { from: 'neptune', to: 'lua', stage: 3, kind: 'return', bend: -0.12 },
  { from: 'pluto', to: 'eris', stage: 3, kind: 'main' },
  { from: 'pluto', to: 'sedna', stage: 3, kind: 'branch', bend: 0.15 },
  { from: 'pluto', to: 'kuva', stage: 3, kind: 'branch', bend: -0.1 },
  { from: 'eris', to: 'deimos', stage: 4, kind: 'return', bend: 0.18 },
  { from: 'eris', to: 'proxima', stage: 5, kind: 'main', bend: -0.1 },
  { from: 'proxima', to: 'zariman', stage: 6, kind: 'main', bend: -0.12 },
  { from: 'zariman', to: 'sanctum', stage: 6, kind: 'main', bend: 0.3 },
  { from: 'sanctum', to: 'duviri', stage: 6, kind: 'return', bend: 0.15 },
  { from: 'sanctum', to: 'hollvania', stage: 7, kind: 'main', bend: -0.08 },
  { from: 'sanctum', to: 'cathedrale', stage: 7, kind: 'branch', bend: -0.15 },
  { from: 'hollvania', to: 'earth', stage: 8, kind: 'return', bend: 0.12 }
];
